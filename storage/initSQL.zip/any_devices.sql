-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Jul 08, 2021 at 08:32 AM
-- Server version: 5.6.51-log
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lanycms`
--

-- --------------------------------------------------------

--
-- Table structure for table `any_devices`
--

CREATE TABLE `any_devices` (
  `id` int(11) NOT NULL COMMENT '自增id',
  `did` varchar(60) NOT NULL COMMENT '设备deviceid',
  `jp_regid` varchar(60) NOT NULL COMMENT 'jpush设备注册id',
  `apikey` varchar(60) NOT NULL COMMENT '动态生成的apikey',
  `status` int(11) NOT NULL COMMENT '该设备是否禁用',
  `ip` varchar(60) NOT NULL COMMENT '注册设备的ip地址',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `extra` text NOT NULL COMMENT '设备额外信息',
  `user_tags` text NOT NULL COMMENT '用户特征集json'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备信息表';

--
-- Dumping data for table `any_devices`
--

INSERT INTO `any_devices` (`id`, `did`, `jp_regid`, `apikey`, `status`, `ip`, `updatetime`, `createtime`, `extra`, `user_tags`) VALUES
(1, '12334', '', '47e19bc8f0c1a0515b25123c8ae4ad0e', 1, '127.0.0.1', 1447409754, 1447405811, '{}', ''),
(2, 'web', '555666', '4e058038ab97742c5cbb7ba9a8451df8', 1, '127.0.0.1', 1447411289, 1447405845, '{}', ''),
(3, 'webdev', '', '07e0672247c58be658b1a9ad5c0076c6', 1, '127.0.0.1', 1457350608, 1447417715, '{}', '{\"air\":[\"hainanairline\",\"ua\"],\"hotel\":[\"starwood\"],\"bank\":[\"CCB\",\"unionpay\",\"DC\",\"NJCB\",\"discover\",\"CC\"]}'),
(4, 'web1dev', '', '04330efd848e668ceb0d69e2c2c07f9f', 1, '127.0.0.1', 1457414299, 1457414239, '{}', '{\"air\":[],\"hotel\":[\"ihg\"],\"bank\":[]}'),
(5, 'webdefaultdev', '', 'dca91c00c7c2648094f9fa33707b3569', 1, '127.0.0.1', 1457414704, 1457414704, '{}', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `any_devices`
--
ALTER TABLE `any_devices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `did` (`did`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `any_devices`
--
ALTER TABLE `any_devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id', AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
