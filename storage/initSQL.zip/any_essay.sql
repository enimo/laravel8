-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Jul 08, 2021 at 08:35 AM
-- Server version: 5.6.51-log
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lanycms`
--

-- --------------------------------------------------------

--
-- Table structure for table `any_essay`
--

CREATE TABLE `any_essay` (
  `essay_id` bigint(20) UNSIGNED NOT NULL,
  `essay_title` text NOT NULL COMMENT '文章标题',
  `essay_author` varchar(60) NOT NULL COMMENT '文章作者',
  `essay_editor` varchar(60) NOT NULL COMMENT '编辑',
  `essay_publisher` varchar(60) NOT NULL COMMENT '后台发布人',
  `essay_content` text NOT NULL COMMENT '文章内容',
  `essay_quote` text NOT NULL COMMENT '引言',
  `essay_categoryid` int(4) UNSIGNED NOT NULL COMMENT '栏目ID',
  `essay_createtime` int(11) UNSIGNED NOT NULL COMMENT '文章创建时间',
  `essay_updatetime` varchar(20) NOT NULL COMMENT '最后更改时间',
  `essay_status` varchar(20) NOT NULL COMMENT '状态（初稿/已编辑/已审核/投稿）',
  `essay_source` text NOT NULL COMMENT '来源',
  `essay_click` bigint(20) UNSIGNED NOT NULL DEFAULT '1' COMMENT '点击量',
  `essay_like` int(11) NOT NULL COMMENT '收藏数',
  `essay_vote` int(11) NOT NULL COMMENT '点赞数',
  `essay_isurl` varchar(255) NOT NULL COMMENT '是否有外链',
  `essay_withpic` tinyint(4) NOT NULL COMMENT '是否带图',
  `essay_commentstatus` varchar(20) NOT NULL COMMENT '评论开关',
  `essay_commentcount` int(11) UNSIGNED NOT NULL COMMENT '评论数量',
  `essay_password` varchar(20) NOT NULL COMMENT '加密文章',
  `essay_essaytype` varchar(20) NOT NULL COMMENT '文章类型',
  `essay_score` varchar(20) NOT NULL COMMENT '评分',
  `essay_top` int(4) UNSIGNED NOT NULL COMMENT '置顶',
  `essay_tag` text NOT NULL COMMENT '关键词',
  `essay_contribute` text NOT NULL COMMENT '投稿人信息'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `any_essay`
--

INSERT INTO `any_essay` (`essay_id`, `essay_title`, `essay_author`, `essay_editor`, `essay_publisher`, `essay_content`, `essay_quote`, `essay_categoryid`, `essay_createtime`, `essay_updatetime`, `essay_status`, `essay_source`, `essay_click`, `essay_like`, `essay_vote`, `essay_isurl`, `essay_withpic`, `essay_commentstatus`, `essay_commentcount`, `essay_password`, `essay_essaytype`, `essay_score`, `essay_top`, `essay_tag`, `essay_contribute`) VALUES
(68, 'add new pic', 'rocky', 'abc', 'enimo', '<p style=\"text-align:center;\">\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323050055_18685.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323050225_32427.png\" alt=\"\" /><img src=\"/demo/uploadfile/image/20140323/20140323052330_37171.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	大大哈哈\r\n</p>\r\n<p>\r\n	奥德赛\r\n</p>', '', 31, 1395522041, '2014-03-23 05:00:41', 'pub', '原创', 1, 0, 0, '', 0, '', 0, '', '', '', 0, '图片||', ''),
(69, '测试插入地图', 'rocky', 'dd', 'enimo', '<p>\r\n	<img src=\"http://aliyun/demo/common/kindeditor4.1.10/plugins/emoticons/images/1.gif\" border=\"0\" alt=\"\" />&nbsp; 不错啊\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<iframe src=\"http://aliyun/demo/common/kindeditor4.1.10/plugins/baidumap/index.html?center=121.377515%2C31.255089&zoom=10&width=558&height=360&markers=121.377515%2C31.255089&markerStyles=l%2CA\" frameborder=\"0\" style=\"width:560px;height:362px;\">\r\n	</iframe>\r\n</p>', '', 23, 1395522197, '2014-03-23 05:03:17', 'pub', '原创', 13, 1, 0, '', 0, '', 0, '', '', '', 0, '地图||', ''),
(70, '测试缩略图生成', 'rocky', '', 'enimo', '<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323151923_75207.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	测试一个缩略图拉着~~\r\n</p>', '', 23, 1395559121, '2014-03-23 15:18:41', 'pub', '原创', 12, 0, 1, '', 1, '', 0, '', '', '', 0, '缩略图||', ''),
(71, '意见反馈', 'rocky', '', 'enimo', '<p>\r\n	大赛大撒\r\n</p>\r\n<p>\r\n	<img src=\"/uploadfile/image/20151112/20151112143915_42381.png\" alt=\"\" />\r\n</p>\r\n<p>\r\n	又来了啊\r\n</p>\r\n<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323171645_35588.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	大赛大牙牙牙\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323173213_23501.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	大多是\r\n</p>\r\n<p>\r\n	大赛大\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323173534_71207.jpg\" alt=\"\" /> \r\n</p>', '', 23, 1395566169, '2014-03-23 17:16:09', 'pub', '原创', 150, 1, 0, '', 1, '', 0, '', '', '', 0, '缩略图||', ''),
(18, '葫芦娃', '葫芦娃', '', '', '<IMG style=\"WIDTH: 500px; HEIGHT: 353px\" src=\"http://safe/anycms/uploadfile/200912121260638572.jpg\"><IMG style=\"WIDTH: 500px; HEIGHT: 353px\" src=\"http://safe/anycms/uploadfile/200912091260341523.jpg\"> ', '', 13, 1260341516, '2009-12-09 14:51:56', 'pub', '', 6, 0, 0, '', 1, '', 0, '', '', '', 0, '', ''),
(78, '测试rest接口', 'dawanjia', '', 'enimo', '哈哈哈可以了', '', 23, 1442066386, '2015-09-12 13:59:46', 'pub', 'www.baidu.com', 26, 1, 0, '', 0, '', 0, '', '', '', 0, '酒店||', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `any_essay`
--
ALTER TABLE `any_essay`
  ADD PRIMARY KEY (`essay_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `any_essay`
--
ALTER TABLE `any_essay`
  MODIFY `essay_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
