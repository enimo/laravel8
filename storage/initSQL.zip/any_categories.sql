-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Jul 08, 2021 at 08:35 AM
-- Server version: 5.6.51-log
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lanycms`
--

-- --------------------------------------------------------

--
-- Table structure for table `any_categories`
--

CREATE TABLE `any_categories` (
  `categories_id` bigint(20) UNSIGNED NOT NULL COMMENT '分类ID',
  `categories_name` varchar(50) NOT NULL COMMENT '分类名称',
  `categories_englishname` varchar(255) NOT NULL COMMENT '英语名称',
  `categories_parentid` varchar(15) NOT NULL COMMENT '父类ID',
  `categories_status` varchar(10) NOT NULL COMMENT '栏目显示与否',
  `categories_pubtype` varchar(20) NOT NULL COMMENT '链接显示方式',
  `categories_type` int(4) NOT NULL COMMENT '类别待定',
  `categories_sort` int(11) NOT NULL COMMENT '栏目排序',
  `categories_createtime` int(11) NOT NULL COMMENT '创建的时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `any_categories`
--

INSERT INTO `any_categories` (`categories_id`, `categories_name`, `categories_englishname`, `categories_parentid`, `categories_status`, `categories_pubtype`, `categories_type`, `categories_sort`, `categories_createtime`) VALUES
(2, '测试栏目专用', 'test', '0', '0', 'list', 0, 4, 1259530337),
(12, '信息中心', 'chinanews', '0', '0', 'list', 0, 999, 1259579432),
(13, '概况', 'about', '12', '1', 'list', 0, 1, 1259579462),
(122, '二级栏目2', 'erjilanmu2', '13', '1', 'list', 0, 0, 1396244169),
(20, '二级测试栏目', 'testcolumn2', '2', '1', 'list', 0, 8, 1259580280),
(23, '热门', 'academyNews', '123', '1', 'list', 0, 1, 1259850425),
(30, '最新通知', 'newNotice', '12', '0', 'list', 0, 8, 1260102908),
(31, '新闻中心', 'hangqing', '13', '1', 'list', 0, 0, 1260354290),
(123, '玩在当下', 'wanzaidangxia', '0', '1', 'cate', 0, 1, 1446826201),
(124, '信用卡', 'xinyongka', '123', '1', 'list', 0, 2, 1446826243),
(125, '酒店', 'jiudian', '123', '1', 'list', 0, 3, 1446826259),
(126, '航空', 'hangkong', '123', '1', 'list', 0, 4, 1446826282),
(127, '投资理财', 'touzilicai', '123', '1', 'list', 0, 5, 1446826302),
(128, '焦点图', 'jiaodiantu', '123', '0', 'list', 0, 1, 1446907406),
(129, '首页', 'dangxiashouye', '0', '1', 'cate', 0, 1, 1447746383),
(130, '新手入门', 'university', '129', '1', 'list', 0, 1, 1447746402),
(131, '今日排行', 'stats-bars', '129', '1', 'list', 0, 3, 1447746432),
(132, '最新活动', 'wand', '129', '1', 'list', 0, 2, 1447746478),
(133, '其他信息', 'qitaxinxi', '123', '0', 'list', 0, 999, 1447932883),
(134, '抓数据栏目', 'zhuashujulanmu', '123', '0', 'list', 0, 99, 1448369743);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `any_categories`
--
ALTER TABLE `any_categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `any_categories`
--
ALTER TABLE `any_categories`
  MODIFY `categories_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '分类ID', AUTO_INCREMENT=135;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
