-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Jul 19, 2021 at 01:24 PM
-- Server version: 8.0.25
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weda`
--

-- --------------------------------------------------------

--
-- Table structure for table `any_categories`
--

CREATE TABLE `any_categories` (
  `categories_id` bigint UNSIGNED NOT NULL COMMENT '分类ID',
  `categories_name` varchar(50) NOT NULL COMMENT '分类名称',
  `categories_englishname` varchar(255) NOT NULL COMMENT '英语名称',
  `categories_parentid` varchar(15) NOT NULL COMMENT '父类ID',
  `categories_status` varchar(10) NOT NULL COMMENT '栏目显示与否',
  `categories_pubtype` varchar(20) NOT NULL COMMENT '链接显示方式',
  `categories_type` int NOT NULL COMMENT '类别待定',
  `categories_sort` int NOT NULL COMMENT '栏目排序',
  `categories_createtime` int NOT NULL COMMENT '创建的时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `any_categories`
--

INSERT INTO `any_categories` (`categories_id`, `categories_name`, `categories_englishname`, `categories_parentid`, `categories_status`, `categories_pubtype`, `categories_type`, `categories_sort`, `categories_createtime`) VALUES
(2, '测试栏目专用', 'test', '0', '0', 'list', 0, 4, 1259530337),
(12, '信息中心', 'chinanews', '0', '0', 'list', 0, 999, 1259579432),
(13, '概况', 'about', '12', '1', 'list', 0, 1, 1259579462),
(122, '二级栏目2', 'erjilanmu2', '13', '1', 'list', 0, 0, 1396244169),
(20, '二级测试栏目', 'testcolumn2', '2', '1', 'list', 0, 8, 1259580280),
(23, '热门', 'academyNews', '123', '1', 'list', 0, 1, 1259850425),
(30, '最新通知', 'newNotice', '12', '0', 'list', 0, 8, 1260102908),
(31, '新闻中心', 'hangqing', '13', '1', 'list', 0, 0, 1260354290),
(123, '玩在当下', 'wanzaidangxia', '0', '1', 'cate', 0, 1, 1446826201),
(124, '信用卡', 'xinyongka', '123', '1', 'list', 0, 2, 1446826243),
(125, '酒店', 'jiudian', '123', '1', 'list', 0, 3, 1446826259),
(126, '航空', 'hangkong', '123', '1', 'list', 0, 4, 1446826282),
(127, '投资理财', 'touzilicai', '123', '1', 'list', 0, 5, 1446826302),
(128, '焦点图', 'jiaodiantu', '123', '0', 'list', 0, 1, 1446907406),
(129, '首页', 'dangxiashouye', '0', '1', 'cate', 0, 1, 1447746383),
(130, '新手入门', 'university', '129', '1', 'list', 0, 1, 1447746402),
(131, '今日排行', 'stats-bars', '129', '1', 'list', 0, 3, 1447746432),
(132, '最新活动', 'wand', '129', '1', 'list', 0, 2, 1447746478),
(133, '其他信息', 'qitaxinxi', '123', '0', 'list', 0, 999, 1447932883),
(134, '抓数据栏目', 'zhuashujulanmu', '123', '0', 'list', 0, 99, 1448369743);

-- --------------------------------------------------------

--
-- Table structure for table `any_devices`
--

CREATE TABLE `any_devices` (
  `id` int NOT NULL COMMENT '自增id',
  `did` varchar(60) NOT NULL COMMENT '设备deviceid',
  `jp_regid` varchar(60) NOT NULL COMMENT 'jpush设备注册id',
  `apikey` varchar(60) NOT NULL COMMENT '动态生成的apikey',
  `status` int NOT NULL COMMENT '该设备是否禁用',
  `ip` varchar(60) NOT NULL COMMENT '注册设备的ip地址',
  `updatetime` int NOT NULL COMMENT '更新时间',
  `createtime` int NOT NULL COMMENT '创建时间',
  `extra` text NOT NULL COMMENT '设备额外信息',
  `user_tags` text NOT NULL COMMENT '用户特征集json'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='设备信息表';

--
-- Dumping data for table `any_devices`
--

INSERT INTO `any_devices` (`id`, `did`, `jp_regid`, `apikey`, `status`, `ip`, `updatetime`, `createtime`, `extra`, `user_tags`) VALUES
(1, '12334', '', '47e19bc8f0c1a0515b25123c8ae4ad0e', 1, '127.0.0.1', 1447409754, 1447405811, '{}', ''),
(2, 'web', '555666', '4e058038ab97742c5cbb7ba9a8451df8', 1, '127.0.0.1', 1447411289, 1447405845, '{}', ''),
(3, 'webdev', '', '07e0672247c58be658b1a9ad5c0076c6', 1, '127.0.0.1', 1457350608, 1447417715, '{}', '{\"air\":[\"hainanairline\",\"ua\"],\"hotel\":[\"starwood\"],\"bank\":[\"CCB\",\"unionpay\",\"DC\",\"NJCB\",\"discover\",\"CC\"]}'),
(4, 'web1dev', '', '04330efd848e668ceb0d69e2c2c07f9f', 1, '127.0.0.1', 1457414299, 1457414239, '{}', '{\"air\":[],\"hotel\":[\"ihg\"],\"bank\":[]}'),
(5, 'webdefaultdev', '', 'dca91c00c7c2648094f9fa33707b3569', 1, '127.0.0.1', 1457414704, 1457414704, '{}', '');

-- --------------------------------------------------------

--
-- Table structure for table `any_essay`
--

CREATE TABLE `any_essay` (
  `essay_id` bigint UNSIGNED NOT NULL,
  `essay_title` text NOT NULL COMMENT '文章标题',
  `essay_author` varchar(60) NOT NULL COMMENT '文章作者',
  `essay_editor` varchar(60) NOT NULL COMMENT '编辑',
  `essay_publisher` varchar(60) NOT NULL COMMENT '后台发布人',
  `essay_content` text NOT NULL COMMENT '文章内容',
  `essay_quote` text NOT NULL COMMENT '引言',
  `essay_categoryid` int UNSIGNED NOT NULL COMMENT '栏目ID',
  `essay_createtime` int UNSIGNED NOT NULL COMMENT '文章创建时间',
  `essay_updatetime` varchar(20) NOT NULL COMMENT '最后更改时间',
  `essay_status` varchar(20) NOT NULL COMMENT '状态（初稿/已编辑/已审核/投稿）',
  `essay_source` text NOT NULL COMMENT '来源',
  `essay_click` bigint UNSIGNED NOT NULL DEFAULT '1' COMMENT '点击量',
  `essay_like` int NOT NULL COMMENT '收藏数',
  `essay_vote` int NOT NULL COMMENT '点赞数',
  `essay_isurl` varchar(255) NOT NULL COMMENT '是否有外链',
  `essay_withpic` tinyint NOT NULL COMMENT '是否带图',
  `essay_commentstatus` varchar(20) NOT NULL COMMENT '评论开关',
  `essay_commentcount` int UNSIGNED NOT NULL COMMENT '评论数量',
  `essay_password` varchar(20) NOT NULL COMMENT '加密文章',
  `essay_essaytype` varchar(20) NOT NULL COMMENT '文章类型',
  `essay_score` varchar(20) NOT NULL COMMENT '评分',
  `essay_top` int UNSIGNED NOT NULL COMMENT '置顶',
  `essay_tag` text NOT NULL COMMENT '关键词',
  `essay_contribute` text NOT NULL COMMENT '投稿人信息'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `any_essay`
--

INSERT INTO `any_essay` (`essay_id`, `essay_title`, `essay_author`, `essay_editor`, `essay_publisher`, `essay_content`, `essay_quote`, `essay_categoryid`, `essay_createtime`, `essay_updatetime`, `essay_status`, `essay_source`, `essay_click`, `essay_like`, `essay_vote`, `essay_isurl`, `essay_withpic`, `essay_commentstatus`, `essay_commentcount`, `essay_password`, `essay_essaytype`, `essay_score`, `essay_top`, `essay_tag`, `essay_contribute`) VALUES
(68, 'add new pic', 'rocky', 'abc', 'enimo', '<p style=\"text-align:center;\">\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323050055_18685.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p style=\"text-align:center;\">\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323050225_32427.png\" alt=\"\" /><img src=\"/demo/uploadfile/image/20140323/20140323052330_37171.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	大大哈哈\r\n</p>\r\n<p>\r\n	奥德赛\r\n</p>', '', 31, 1395522041, '2014-03-23 05:00:41', 'pub', '原创', 1, 0, 0, '', 0, '', 0, '', '', '', 0, '图片||', ''),
(69, '测试插入地图', 'rocky', 'dd', 'enimo', '<p>\r\n	<img src=\"http://aliyun/demo/common/kindeditor4.1.10/plugins/emoticons/images/1.gif\" border=\"0\" alt=\"\" />&nbsp; 不错啊\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<iframe src=\"http://aliyun/demo/common/kindeditor4.1.10/plugins/baidumap/index.html?center=121.377515%2C31.255089&zoom=10&width=558&height=360&markers=121.377515%2C31.255089&markerStyles=l%2CA\" frameborder=\"0\" style=\"width:560px;height:362px;\">\r\n	</iframe>\r\n</p>', '', 23, 1395522197, '2014-03-23 05:03:17', 'pub', '原创', 13, 1, 0, '', 0, '', 0, '', '', '', 0, '地图||', ''),
(70, '测试缩略图生成', 'rocky', '', 'enimo', '<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323151923_75207.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	测试一个缩略图拉着~~\r\n</p>', '', 23, 1395559121, '2014-03-23 15:18:41', 'pub', '原创', 12, 0, 1, '', 1, '', 0, '', '', '', 0, '缩略图||', ''),
(71, '意见反馈', 'rocky', '', 'enimo', '<p>\r\n	大赛大撒\r\n</p>\r\n<p>\r\n	<img src=\"/uploadfile/image/20151112/20151112143915_42381.png\" alt=\"\" />\r\n</p>\r\n<p>\r\n	又来了啊\r\n</p>\r\n<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323171645_35588.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	大赛大牙牙牙\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323173213_23501.jpg\" alt=\"\" /> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	大多是\r\n</p>\r\n<p>\r\n	大赛大\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<img src=\"/demo/uploadfile/image/20140323/20140323173534_71207.jpg\" alt=\"\" /> \r\n</p>', '', 23, 1395566169, '2014-03-23 17:16:09', 'pub', '原创', 150, 1, 0, '', 1, '', 0, '', '', '', 0, '缩略图||', ''),
(18, '葫芦娃', '葫芦娃', '', '', '<IMG style=\"WIDTH: 500px; HEIGHT: 353px\" src=\"http://safe/anycms/uploadfile/200912121260638572.jpg\"><IMG style=\"WIDTH: 500px; HEIGHT: 353px\" src=\"http://safe/anycms/uploadfile/200912091260341523.jpg\"> ', '', 13, 1260341516, '2009-12-09 14:51:56', 'pub', '', 6, 0, 0, '', 1, '', 0, '', '', '', 0, '', ''),
(78, '测试rest接口', 'dawanjia', '', 'enimo', '哈哈哈可以了', '', 23, 1442066386, '2015-09-12 13:59:46', 'pub', 'www.baidu.com', 26, 1, 0, '', 0, '', 0, '', '', '', 0, '酒店||', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `email_verified_at`) VALUES
(1, 'rocky111', '111@weda.com', '111', '0000-00-00'),
(2, 'rocky222', '222@weda.com', '222', '0000-00-00'),
(300, 'rocky333', '333@weda.com', '333', '0000-00-00'),
(301, 'rocky444', '444@weda.com', '444', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `any_categories`
--
ALTER TABLE `any_categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- Indexes for table `any_devices`
--
ALTER TABLE `any_devices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `did` (`did`);

--
-- Indexes for table `any_essay`
--
ALTER TABLE `any_essay`
  ADD PRIMARY KEY (`essay_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `any_categories`
--
ALTER TABLE `any_categories`
  MODIFY `categories_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '分类ID', AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `any_devices`
--
ALTER TABLE `any_devices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT COMMENT '自增id', AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `any_essay`
--
ALTER TABLE `any_essay`
  MODIFY `essay_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
